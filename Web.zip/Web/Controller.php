<?php

if((isset($_POST['ArticleName']) && !empty($_POST['ShopPrice']) && !empty($_POST['ClientPrice']) && !empty($_POST['Unit'])))
{
    $ArticleName = $_POST['ArticleName'];
    $PrixFournisseur = $_POST['ShopPrice'];
    $ClientPrice = $_POST['ClientPrice'];
    $Unit = $_POST['Unit'];
    $refPersonne = $_COOKIE['refPersonnes'];
    $description = $_POST['description'];
    $ImageURL = $_POST['PictureURL'];
    
     $query = "call AddProduit('$refPersonne', '$ArticleName', '$description', '$PrixFournisseur', '$ClientPrice', '$Unit', '$ImageURL')";
     $reponse = $bdd->prepare($query);
     $reponse->execute();
     $records = $reponse->fetch(PDO::FETCH_ASSOC);
 
}

?>