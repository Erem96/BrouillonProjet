<?php
require ROOT.'index.php'; /*recuperation du controler */
echo 'hollywood';

?>