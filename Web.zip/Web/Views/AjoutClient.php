<form action="./index.php?action=ajoutClient" method="post"> 
            <input type="text" name="prenom" id="prenom" required>* prenom <br> <br>
            <input type="text" name="nom" id="nom" required>* nom <br> <br>
            <input type="text" name="pseudo" id="pseudo" required>* pseudo <br> <br>
            <input type="password" name="password" id="password" required>* password <br> <br>
            <input type="text" name="mail" id="mail" required>* mail <br> <br>
            <input type="submit"> 