<?php
 echo '<br><a href="?action=listeArticle">Articles</a><br><a href="?action=listeClient">Clients</a><br>';

?>
