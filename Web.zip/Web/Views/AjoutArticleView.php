AJOUTER UN ARTICLE 
    <form action="./index.php?action=ajoutArticle" method="post" id="addArticle"> 

    <input type="text" name="ArticleName" id="ArticleName">Nom de l'article<br><br>
    <textarea name="description" form="addArticle">Description</textarea><br><br>
    <input type="text" name="ShopPrice" id="ShopPrice">Prix fournisseur<br><br>
    <input type="text" name="ClientPrice" id="ClientPrice">Prix client<br><br>
    <input type="text" name="PictureURL"> id de l'image  <br><br>
    <input type="text" name="Unit" id="Unit">Unit<br><br>
    <input type="submit">
    </form>
