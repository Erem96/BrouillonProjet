<?php

        $reponse = $bdd->prepare($query);
        $reponse->execute();
?>