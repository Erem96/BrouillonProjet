<?php

class comptesLists{

protected $comptes;
public function __construct()
{

    $this->table =  'personnes';
    require ROOT.'DBScript/bdd.php';
    $query = $bdd->prepare("select refPersonnes, pseudo, adresseMail, statut from personnes");
    $query->execute();
    
    $this->comptes = array();
    foreach($query->fetchAll() as $key => $value)
    {
        
        $compte = new compte();
        $compte->refPersonnes = $value['refPersonnes'];
        $compte->pseudo= $value['pseudo'];
        $compte->adresseMail= $value['adresseMail'];
        $compte->statut= $value['statut'];
        
        array_push($this->comptes, $compte);
    }
}

public function ListeCompte()
{
    require ROOT.'Views/ListeCompte.php'; /*recuperation du controler */

}

}

class compte {

    protected $table; /*Pour réduire les risques de fuites de données, les noms, et mot de passes ne sortent pas de la DB*/
    public $refPersonnes;
    public $pseudo;
    public $adresseMail;
    public $statut;

    public function __construct()
    {
        $this->table =  'personnes';
    }

public function afficher(){
    echo 'afficher personne';
    
   

    // $query = "call DeleteProduit('$refChoice', '$ref')";
    // $reponse = $bdd->prepare($query);
    // $reponse->execute();

    // $records = $reponse->fetchAll(PDO::FETCH_ASSOC);


}
}

?>