<?php

 class inventaire{

    protected $articles;
    public function __construct()
    {
    
        $this->table =  'produits';
        require ROOT.'DBScript/bdd.php';
        $query = $bdd->prepare("select * from produits");
        $query->execute();
        
        $this->articles = array();
        foreach($query->fetchAll() as $key => $value)
        {
            
            $na = new article();
            $na->refProduit = $value['refProduit'];
            $na->nomProduit= $value['nomProduit'];
            $na->descriptionProduit= $value['descriptionProduit'];
            $na->prixAchatParUnit= $value['prixAchatParUnit'];
            $na->qtt=2;
            $na->prixVenteParUnit= $value['prixVenteParUnit'];
            $na->unit= $value['unit'];
            $na->illustrationURL= $value['illustrationUrl'];
            
            array_push($this->articles, $na);
        }
    }

    public function ListeProduits()
    {
        require ROOT.'Views/ListeArticles.php'; /*recuperation du controler */
    
    }

    public function AjouterArticle()
    {
        require ROOT.'Views/ListeArticles.php'; /*recuperation du controler */
    
    }
    


 }

 class article {

    protected $table;
    public $refProduit;
    public $nomProduit;
    public $descriptionProduit;
    public $prixAchatParUnit;
    public $qtt;
    public $prixVenteParUnit;
    public $unit;
    public $illustrationURL;
    public $dateEncodage;
    public $userCreator;

    public function __construct()
    {
        $this->table =  'produits';
    }

public function afficher(){
    echo 'afficher article';
    
   

    // $query = "call DeleteProduit('$refChoice', '$ref')";
    // $reponse = $bdd->prepare($query);
    // $reponse->execute();

    // $records = $reponse->fetchAll(PDO::FETCH_ASSOC);


}


}
?>