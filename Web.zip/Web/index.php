
<?php

define('ROOT', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME'])); /*defini le chemin du server*/
require ROOT.'Views/Template/header.php';


$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = trim($uri, '/');
$segments = array_filter(explode('/', $uri));

if (!count($segments) or $segments[0] == 'index'){
    $segments[0] = 'basePage';
}


if (strpos($_SERVER['REQUEST_URI'], 'listeArticle')  != false) {
    
    require ROOT.'app/controller.php'; 
    require ROOT.'app/model.php'; 
    $sa = new inventaire();
    $sa->ListeProduits();
    require ROOT.'Views/AjoutArticleView.php';

}

if (strpos($_SERVER['REQUEST_URI'], 'listeClient')  != false) {
    
    require ROOT.'app/UserModel.php';
    $sa = new comptesLists();
    $sa->ListeCompte();
    require ROOT.'app/ControllerAjoutClient.php';
    
}


if (strpos($_SERVER['REQUEST_URI'], 'ajoutArticle')  != false) {
    require ROOT.'DBScript/bdd.php';
    require ROOT.'app/controller.php'; 
    require ROOT.'app/model.php'; 
    require ROOT.'app/ControllerAjoutArticle.php';
    $sa = new inventaire();
    $sa->ListeProduits();
}

?>